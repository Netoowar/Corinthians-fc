import React from "react";


function Footer(){
    return(
        <footer>
            <div></div>
        </footer>
    );
}

export default Footer;